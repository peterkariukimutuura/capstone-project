<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
     <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Welcome <?php echo e(Auth::user()->name); ?>  
                    
               </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="row">
                        <?php if($todos->count() > 0): ?>
                        <table class="table table-striped">
                            <thead>
                                <th colspan="2">Todos</th>
                                <th>Created</th>
                                <th>Action</th>
                            </thead>
                            <?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td colspan="2"><?php echo e($todo->name); ?></td>
                                <td><?php echo e($todo->created_at->diffForHumans()); ?></td>
                                <td><a href="/todo/delete/<?php echo e($todo->id); ?>">Delete</a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </table>
                        <?php echo e($todos->links()); ?>

                        <hr>
                        <?php else: ?>
                        <div class="alert alert-info text-center" style="width: 100%;">
                            You have not added any Todos! 
                        </div>
                        <a class="nav-link text-center"  href="<?php echo e(route('todo')); ?>">Click to add Todo</a>
                        <?php endif; ?>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>